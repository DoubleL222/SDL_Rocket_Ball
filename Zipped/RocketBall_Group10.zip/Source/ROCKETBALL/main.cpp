#include "RocketBall.h"

int main()
{
	new RocketBall();
	return 0;
}